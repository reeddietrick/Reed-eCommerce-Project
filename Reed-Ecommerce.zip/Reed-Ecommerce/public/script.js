// Add event listeners for search input and sorting dropdown
document.getElementById('searchInput').addEventListener('input', updateProducts);
document.getElementById('sorting').addEventListener('change', updateProducts);

// Function to update products
async function updateProducts() {
  try {
    const name = document.getElementById('searchInput').value;
    const sortingOption = document.getElementById('sorting').value;

    const response = await fetch('/api/products', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, sortingOption }),
    });

    if (response.ok) {
      const products = await response.json();
      const container = document.getElementById('productsList');
      container.innerHTML = '';

      products.forEach(product => {
        const productElement = `
          <div class="col-lg-4 col-md-6 mb-3"> <!-- Reduced mb-4 to mb-3 -->
            <div class="card h-100">
              <img src="${product.image}" class="card-img-top" alt="${product.name}" data-toggle="modal" data-target="#productModal${product._id}">
              <div class="quick-shop-overlay" data-toggle="modal" data-target="#productModal${product._id}">
                <p class="quick-shop-text">Quick Shop</p>
              </div>
              <div class="card-body">
                <h5 class="card-title">${product.name}</h5>
                <p class="card-text">$${product.price}</p>
              </div>
            </div>
          </div>

          <!-- Modal -->
          <div class="modal fade" id="productModal${product._id}" tabindex="-1" aria-labelledby="productModalLabel${product._id}" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
              <div class="modal-content">
                <div class="modal-header" style="background-color: #ffe6e6; color: #261711;">
                  <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <div class="row">
                    <div class="col-md-6">
                      <img src="${product.image}" class="img-fluid mb-3 rounded" alt="${product.name}">
                    </div>
                    <div class="col-md-6">
                      <h3 class="modal-title" id="productModalLabel${product._id}"> ${product.name}</h3>
                      <p>Price: <span style="color: #261711;">$${product.price}</span></p>
                      <p class="font-italic">${product.description}</p>
                      <p>Available Stock: ${product.stock}</p>

                      <!-- Quantity selection and add to cart form -->
                      <form class="mt-3" action="/addToCart" method="POST">
                        <label for="quantity-${product.name}" class="font-weight-bold">Quantity:</label>
                        <input type="number" id="quantity-${product.name}" name="quantity" value="1" class="form-control cart-quantity" data-product-id="${product._id}">
                        <input type="hidden" name="productId" value="${product._id}">
                        <button type="submit" class="btn" style="background-color: #ffe6e6;">Add to Cart</button>
                      </form>
                    </div>
                  </div>
                </div>
                <div class="modal-footer" style="background-color: #ffe6e6;">
                  <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        `;
        container.innerHTML += productElement;
      });
    } else {
      console.error('Response not ok with status:', response.status);
    }
  } catch (error) {
    console.error('Fetch error:', error.message);
  }
}

// Call the updateProducts function when the page loads
updateProducts();

// Add event listeners for quantity input fields
document.addEventListener('DOMContentLoaded', () => {
  const quantityInputs = document.querySelectorAll('.cart-quantity');
  quantityInputs.forEach(input => {
    input.addEventListener('input', () => {
      const productId = input.dataset.productId;
      const newQuantity = parseInt(input.value);
      updateCartItem(productId, newQuantity);
    });
  });
});

async function updateCartItem(productId, newQuantity) {
  try {
    const response = await fetch('/updateCartItem', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ productId, quantity: newQuantity }),
    });
    
    if (response.ok) {
      const updatedCartItem = await response.json();
      // Update the UI to reflect the new quantity
      const totalPriceElement = document.getElementById(`totalPrice-${productId}`);
      const totalPrice = updatedCartItem.price * updatedCartItem.quantity;
      totalPriceElement.textContent = `$${totalPrice.toFixed(2)}`;
    } else {
      console.error('Failed to update cart item');
    }
  } catch (error) {
    console.error('Error updating cart item:', error.message);
  }
}

async function removeFromCart(productId) {
  try {
    const response = await fetch('/removeFromCart', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ productId }),
    });
    if (response.ok) {
      // Remove the item from the UI without reloading the page
      const cartItemToRemove = document.getElementById(`cartItem-${productId}`);
      if (cartItemToRemove) {
        cartItemToRemove.parentNode.removeChild(cartItemToRemove); // Remove the row from the table
      } else {
        console.error('Failed to find cart item in UI');
      }
    } else {
      console.error('Failed to remove item from cart');
    }
  } catch (error) {
    console.error('Error removing item from cart:', error);
  }
}
